var s = `1 + 1 = ${1 + 1}`;
assert.equal(s, '1 + 1 = 2');
